import java.util.ArrayList;

public class FileReader implements IO{
    @Override
    public ArrayList<Team> readGameData() {
        return null;
    }

    @Override
    public void saveDataToDB() {

    }
}
