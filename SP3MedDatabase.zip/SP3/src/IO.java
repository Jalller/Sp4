import java.util.ArrayList;

public interface IO {
    public ArrayList<Team> readGameData();
    public void saveDataToDB();



    // maybe tournement implantation here later
}
